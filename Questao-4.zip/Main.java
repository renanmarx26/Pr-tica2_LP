class Main {
  public static void main(String[] args) {
  Scanner entrada = new Scanner(System.in);

  int Cadastro , Checkin , Cancelar , Sair ;
  int Passageiro , Nome , CPF , DataVoo, NumeroVoo , Horario;
  int[] vetor = new int[100];

  System.out.println ("1 - Cadastrar Passageiro\n");
  Cadastro = entrada.nextInt();

    System.out.println ("2 - Check in\n");
  Checkin = entrada.nextInt();

    System.out.println ("3 - Cancelar Voo\n");
  Cancelar = entrada.nextInt();

    System.out.println ("4 - Sair\n");
  Sair = entrada.nextInt();




    
    System.out.println ("\n Caro passageiro, gentileza informar seu Nome Completo,CPF e Numero do voo:");
    if (Passageiro = 'Nome' , 'CPF'  , 'NumeroVoo');{
     System.out.printIn("Cadastro Efetuado com Sucesso");
      

     System.out.println("\n Caro passageiro, gentileza informar seu CPF e Numero do Voo:");
      if else (Passageiro = 'CPF' , 'NumeroVoo'){

      for (int i=0; i<10; i++){
      System.out.printf("\nDigite o numero da poltrona #%d", i+1);

        vetor[i] = entrada.nextInt();

    
  
    
}
}    
}
}
}