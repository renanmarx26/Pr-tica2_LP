class Main {
  public static void main(String[] args) {
    
  int [][] matrizValor = new int [50][50];
    int impar = 1;
    
    for(int linhas = 0;linhas<50;linhas++){
      for(int cols=0; cols<50;cols++){
        matrizValor[linhas][cols] = impar;
        if(linhas==cols)
          System.out.printf("%d\t",matrizValor[linhas][cols]);
        else
          System.out.printf("0\t");
        impar+=2;
        
      }
      System.out.printf("\n");
    }
}
    
}